public class RingBuffer {

    // Creates an empty ring buffer with the specified capacity.
    public RingBuffer(int capacity)

    // Returns the capacity of this ring buffer.
    public int capacity()

    // Returns the number of items currently in this ring buffer.
    public int size()

    // Is this ring buffer empty (size equals zero)?
    public boolean isEmpty()

    // Is this ring buffer full (size equals capacity)?
    public boolean isFull()

    // Adds item x to the end of this ring buffer.
    public void enqueue(double x)

    // Deletes and returns the item at the front of this ring buffer.
    public double dequeue()

    // Returns the item at the front of this ring buffer.
    public double peek()

    // Tests this class by directly calling all instance methods.
    public static void main(String[] args)
}