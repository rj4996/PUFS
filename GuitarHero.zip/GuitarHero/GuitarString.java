public class GuitarString {

    // Creates a guitar string of the specified frequency,
    // using a sampling rate of 44,100.
    public GuitarString(double frequency)

    // Creates a guitar string whose length and initial values
    // are given by the specified array.
    public GuitarString(double[] init)

    // Returns the number of samples in the ring buffer.
    public int length()

    // Returns the current sample.
    public double sample()

    // Plucks this guitar string by replacing the ring buffer with white noise.
    public void pluck()

    // Advances the Karplus-Strong simulation one time step.
    public void tic()

    // Tests this class by directly calling both constructors
    // and all instance methods.
    public static void main(String[] args)
}